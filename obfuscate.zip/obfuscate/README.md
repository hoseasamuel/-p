# Obfuscate & Deobfuscate
# Bash Encrypter & Decrypter
```
$ pkg install nodejs
$ npm install -g bash-obfuscate
$ git clone https://github.com/Syhrularv/obfuscate
$ cd obfuscate
$ python2 bash.py
```
